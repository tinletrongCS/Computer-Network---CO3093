#include "SessionManager.h"

std::map<std::string, std::string> SessionManager::sessions;
