#pragma once
#include <string>
#include <vector>

class BaseModel
{
public:
    virtual ~BaseModel() {}
};
