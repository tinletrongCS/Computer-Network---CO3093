#include "LoginController.h"
#include "core/SessionManager.h"

Response LoginController::handle(const Request &req)
{
    Response res;
    // TODO Implemment
    return res;
}
