#pragma once
#include <string>

class TokenGenerator
{
public:
    static std::string generate();
};