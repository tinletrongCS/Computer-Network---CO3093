#include "StringUtils.h"

std::string StringUtils::trim(const std::string &s)
{
    // TODO
}

std::vector<std::string> StringUtils::split(const std::string &s, char delimiter)
{
    // TODO
}

std::map<std::string, std::string> StringUtils::parseJSON(const std::string &json)
{
    // TODO
}
